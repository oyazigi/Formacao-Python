# DB_Integration

Description.
The Package DB_Integration is used to:
- Make the creation of an integrated Database to make it easier to start coding
- Integrate your APP With MongoDB
- Integrate your APP With SQL

## Installation

Use the package manager [pip](https://pip.pyna.io/en/stable/) to install DB_Integration

'''bash
pip install DB_Integration
'''

## Usage
'''python
from DB_Integration import Task_Pymongo
function_to_be_used_as_example(arg1)
'''

## Author
Victor Yazigi
